import 'package:get/get.dart';
import 'package:recharge_app/app/modules/home/auth/views/login_view.dart';
import 'package:recharge_app/app/modules/home/auth/views/otp_view.dart';
import 'package:recharge_app/app/modules/home/views/payment_method_view.dart';

import '../modules/home/views/bottombar_view.dart';
import '../modules/home/views/splash_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.SPLASH;

  static final routes = [
    GetPage(
      name: _Paths.LOGIN,
      page: () => LoginView(),
    ),
    GetPage(
      name: _Paths.SPLASH,
      page: () => SplashView(),
    ),
    GetPage(
      name: _Paths.OTPVERIFY,
      page: () => OtpView(),
    ),
    GetPage(
      name: _Paths.BOTTOMBAR,
      page: () => BottombarView(),
    ),
    GetPage(
      name: _Paths.PAYMENTMETHOD,
      page: () => PaymentMethodView(),
    ),
  ];
}
