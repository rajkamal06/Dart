import 'package:get/get.dart';

class PaymentMethodController extends GetxController {
  final paymentMode = 1.obs;

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
