import 'package:get/get.dart';

class MobilerechargeController extends GetxController {
  //TODO: Implement MobilerechargeController

  final count = 0.obs;
  final selectvalue = 1.obs;
  final agree = false.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
