import 'package:get/get.dart';

class LoginController extends GetxController {
  final show = true.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
