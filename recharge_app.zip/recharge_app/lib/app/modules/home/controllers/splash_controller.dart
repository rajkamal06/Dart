import 'dart:async';

import 'package:get/get.dart';

import '../auth/views/login_view.dart';

class SplashController extends GetxController {
  // var box = GetStorage();

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  gotopage() {
    return Future.delayed(Duration(seconds: 3), () => Get.offAll(LoginView()));
  }
}
