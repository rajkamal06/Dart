import 'package:get/get.dart';

class LpggasController extends GetxController {
  //TODO: Implement LpggasController

  final count = 0.obs;
  final selectvalue = 1.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
