import 'package:get/get.dart';

import '../views/home_view.dart';
import '../views/myaccount_view.dart';
import '../views/mywallet_view.dart';
import '../views/scan_view.dart';

class BottombarController extends GetxController {
  //TODO: Implement BottombarController

  final currentIndex = 0.obs;
  List children = [HomeView(), MyaccountView(), ScanView(), MywalletView()];
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  onTabTapped(int index) {
    currentIndex.value = index;
  }
}
