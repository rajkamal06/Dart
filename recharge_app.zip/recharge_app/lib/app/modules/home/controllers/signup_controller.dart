import 'package:get/get.dart';

class SignupController extends GetxController {
  //TODO: Implement SignupController

  final show = true.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
