import 'package:get/get.dart';

class HomeController extends GetxController {
  final sliderCurrentIndex = 0.obs;
  final slider = [].obs;
  List imagesname = [
    {
      "name": "Mobile Prepaid",
      "images": "assets/homeimages/mobile-recharge.png"
    },
    {
      "name": "Mobile Postpaid",
      "images": "assets/homeimages/mobile-recharge.png"
    },
    {"name": "DTH", "images": "assets/homeimages/dth.png"},
    {"name": "Datacard Prepaid", "images": "assets/homeimages/paid.png"},
    {"name": "Datacard Postpaid", "images": "assets/homeimages/postpaid.png"},
    {"name": "Landline", "images": "assets/homeimages/Landline.png"},
    {"name": "Electricity", "images": "assets/homeimages/Electricity.png"},
    {"name": "Gas", "images": "assets/homeimages/gas.png"},
    {"name": "Reports", "images": "assets/homeimages/report.png"},
  ].obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
