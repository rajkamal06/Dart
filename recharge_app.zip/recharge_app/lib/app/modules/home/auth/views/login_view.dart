import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:recharge_app/app/modules/home/auth/views/forget_view.dart';
import 'package:recharge_app/app/modules/home/auth/views/signup_view.dart';
import 'package:recharge_app/constants/app_colors.dart';
import 'package:recharge_app/constants/base_style.dart';
import 'package:recharge_app/constants/strings.dart';

import '../../../../../widgets/decoration.dart';
import '../../../../../widgets/design_method.dart';
import '../../controllers/login_controller.dart';
import '../../views/bottombar_view.dart';

class LoginView extends GetView<LoginController> {
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => LoginController());
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: Obx(
          () => Column(
            children: [
              designfunction(name: LoginItems.login),
              const SizedBox(
                height: 50,
              ),
              Expanded(
                child: Container(
                  width: double.infinity,
                  child: Stack(
                    children: [
                      Positioned(
                          top: 0,
                          right: 0,
                          child: Image.asset(
                            ImagePath.tright,
                          )),
                      Positioned(
                          bottom: 0,
                          left: 0,
                          child: Image.asset(
                            ImagePath.bleft,
                          )),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, right: 15.0, top: 20),
                        child: Container(
                          alignment: Alignment.center,
                          height: Get.height * 0.64,
                          width: Get.width,
                          decoration: decoration(),
                          child: Column(
                            // mainAxisAlignment: MainAxisAlignment.center,
                            // crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              heightSpace20,
                              Container(
                                alignment: Alignment.topLeft,
                                padding: EdgeInsets.only(left: 15),
                                child: Text(
                                  LoginItems.mobile,
                                  style: BaseStyles.main14,
                                  // textAlign: TextAlign.left,
                                ),
                              ),
                              heightSpace10,
                              Container(
                                height: 52,
                                width: Get.width * 0.80,
                                alignment: Alignment.center,
                                decoration: decoration(),
                                child: TextField(
                                  // controller: controller.emailtxt,
                                  cursorColor: Theme.of(context).primaryColor,
                                  // style: TextStyle(
                                  //     color: AppColors.greyBackground
                                  //         .withOpacity(0.7)),
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(10)
                                  ],
                                  decoration: InputDecoration(
                                    isDense: true,
                                    contentPadding: EdgeInsets.all(13),
                                    prefixIcon: Padding(
                                        padding: EdgeInsets.all(13),
                                        child: Text(' +91',
                                            style: BaseStyles.main14)),
                                    prefixStyle: BaseStyles.grey12,
                                    hintStyle: TextStyle(
                                        color: AppColors.greyBackground
                                            .withOpacity(0.7)),
                                    hintText: 'Enter your mobile number',
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                              heightSpace20,
                              Container(
                                alignment: Alignment.topLeft,
                                padding: EdgeInsets.only(left: 15),
                                child: Text(
                                  LoginItems.password,
                                  style: BaseStyles.main14,

                                  // textAlign: TextAlign.left,
                                ),
                              ),
                              heightSpace10,
                              Container(
                                height: 52,
                                width: Get.width * 0.80,
                                alignment: Alignment.center,
                                decoration: decoration(),
                                child: TextField(
                                  obscureText: controller.show.value,
                                  // controller: controller.passwordtxt,
                                  cursorColor: Theme.of(context).primaryColor,
                                  style: TextStyle(color: AppColors.blackColor),
                                  decoration: InputDecoration(
                                    hintStyle: TextStyle(
                                        color: AppColors.greyBackground
                                            .withOpacity(0.7)),
                                    suffixIconColor: AppColors.maincolor,
                                    suffixIcon: GestureDetector(
                                        onTap: () {
                                          controller.show.value =
                                              !controller.show.value;
                                        },
                                        child: controller.show.value == true
                                            ? Icon(
                                                Icons.visibility_off,
                                                color: AppColors.maincolor,
                                              )
                                            : Icon(
                                                Icons.visibility,
                                                color: AppColors.maincolor,
                                              )),
                                    isDense: true,
                                    contentPadding: EdgeInsets.all(15),
                                    hintText: 'Password',
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                              heightSpace20,
                              Padding(
                                padding: const EdgeInsets.only(right: 15.0),
                                child: Align(
                                  alignment: Alignment.topRight,
                                  child: GestureDetector(
                                    onTap: () {
                                      // Get.to(() => BottombarView());
                                      Get.to(() => ForgetView());
                                    },
                                    child: Text(
                                      LoginItems.forget,
                                      style: BaseStyles.main14,
                                    ),
                                  ),
                                ),
                              ),
                              heightSpace20,
                              // Row(
                              //   children: [
                              //     widthSpace10,
                              //     Checkbox(
                              //       value: controller.agree.value,
                              //       onChanged: (value) {
                              //         controller.agree.value = value ?? false;
                              //       },
                              //     ),
                              //     Expanded(
                              //       child: Text(
                              //         LoginSignupStrings.accept,
                              //         overflow: TextOverflow.ellipsis,
                              //         style: BaseStyles.black12,
                              //       ),
                              //     )
                              //   ],
                              // ),
                              heightSpace20,
                              Expanded(child: Container()),

                              GestureDetector(
                                onTap: () => Get.to(() => BottombarView()),
                                child: Container(
                                  height: 50,
                                  width: Get.width,
                                  alignment: Alignment.center,
                                  margin: EdgeInsets.only(right: 10, left: 10),
                                  decoration: BoxDecoration(
                                    color: AppColors.maincolor,
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: Text(
                                    LoginItems.login,
                                    style: BaseStyles.whiteBold18,
                                  ),
                                ),
                              ),
                              heightSpace30,
                              RichText(
                                  text: TextSpan(children: [
                                TextSpan(
                                    text: LoginItems.have_account,
                                    style: BaseStyles.black14),
                                TextSpan(
                                    text: LoginItems.signup,
                                    style: BaseStyles.main14,
                                    recognizer: new TapGestureRecognizer()
                                      ..onTap = () {
                                        // Get.toNamed('/signup');
                                        Get.to(() => SignupView());
                                      }),
                              ])),
                              heightSpace30
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ));
  }
}
