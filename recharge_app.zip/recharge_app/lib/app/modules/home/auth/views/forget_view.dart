import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:recharge_app/app/modules/home/auth/views/otp_view.dart';

import '../../../../../constants/app_colors.dart';
import '../../../../../constants/base_style.dart';
import '../../../../../constants/strings.dart';
import '../../../../../widgets/decoration.dart';
import '../../../../../widgets/design_method.dart';
import '../../controllers/forget_controller.dart';

class ForgetView extends GetView<ForgetController> {
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => ForgetController());
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
          designfunction(name: LoginItems.forget1),
          const SizedBox(
            height: 50,
          ),
          Expanded(
            child: Container(
              width: double.infinity,
              child: Stack(
                children: [
                  Positioned(
                      top: 0,
                      right: 0,
                      child: Image.asset(
                        ImagePath.tright,
                      )),
                  Positioned(
                      bottom: 0,
                      left: 0,
                      child: Image.asset(
                        ImagePath.bleft,
                      )),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 15.0, right: 15.0, top: 20),
                    child: Container(
                      alignment: Alignment.center,
                      height: Get.height * 0.64,
                      width: Get.width,
                      decoration: decoration(),
                      child: Column(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        // crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          heightSpace20,
                          Container(
                            alignment: Alignment.topLeft,
                            padding: EdgeInsets.only(left: 15),
                            child: Text(
                              LoginItems.mobile,
                              style: BaseStyles.main14,
                              // textAlign: TextAlign.left,
                            ),
                          ),
                          heightSpace10,
                          Container(
                            height: 52,
                            width: Get.width * 0.80,
                            alignment: Alignment.center,
                            decoration: decoration(),
                            child: TextField(
                              // controller: controller.emailtxt,
                              cursorColor: Theme.of(context).primaryColor,
                              // style: TextStyle(
                              //     color: AppColors.greyBackground
                              //         .withOpacity(0.7)),
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(10)
                              ],
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding: EdgeInsets.all(13),
                                prefixIcon: Padding(
                                    padding: EdgeInsets.all(13),
                                    child:
                                        Text(' +91', style: BaseStyles.main14)),
                                prefixStyle: BaseStyles.grey12,
                                hintStyle: TextStyle(
                                    color: AppColors.greyBackground
                                        .withOpacity(0.7)),
                                hintText: 'Enter your mobile number',
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                          heightSpace50,
                          // Expanded(child: Container()),
                          GestureDetector(
                            onTap: () => Get.to(() => OtpView()),
                            child: Container(
                              height: 50,
                              width: Get.width,
                              alignment: Alignment.center,
                              margin: EdgeInsets.only(right: 10, left: 10),
                              decoration: BoxDecoration(
                                color: AppColors.maincolor,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Text(
                                LoginItems.submit,
                                style: BaseStyles.whiteBold18,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
