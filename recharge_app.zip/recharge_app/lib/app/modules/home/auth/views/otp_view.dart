import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:recharge_app/app/modules/home/auth/views/newpassword_view.dart';
import 'package:recharge_app/constants/app_colors.dart';
import 'package:recharge_app/constants/strings.dart';

import '../../../../../constants/base_style.dart';
import '../../../../../widgets/decoration.dart';
import '../../../../../widgets/design_method.dart';
import '../../views/bottombar_view.dart';

class OtpView extends GetView {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
          designfunction(name: LoginItems.otp),
          const SizedBox(
            height: 50,
          ),
          Expanded(
            child: Container(
              width: double.infinity,
              child: Stack(
                children: [
                  Positioned(
                      top: 0,
                      right: 0,
                      child: Image.asset(
                        ImagePath.tright,
                      )),
                  Positioned(
                      bottom: 0,
                      left: 0,
                      child: Image.asset(
                        ImagePath.bleft,
                      )),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 15.0, right: 15.0, top: 20),
                    child: Container(
                      alignment: Alignment.center,
                      height: Get.height * 0.64,
                      width: Get.width,
                      decoration: decoration(),
                      child: Column(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        // crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          heightSpace20,
                          Container(
                              alignment: Alignment.center,
                              margin: EdgeInsets.all(20),
                              padding: EdgeInsets.all(10),
                              width: MediaQuery.of(context).size.width,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    LoginItems.verificationcode,
                                    style: BaseStyles.black14,
                                    textAlign: TextAlign.center,
                                  ),
                                  SizedBox(
                                    height: 40,
                                  ),
                                  PinCodeTextField(
                                    appContext: context,
                                    length: 6,
                                    obscureText: false,
                                    animationType: AnimationType.fade,
                                    keyboardType: TextInputType.number,
                                    pinTheme: PinTheme(
                                      shape: PinCodeFieldShape.box,
                                      borderRadius: BorderRadius.circular(5),
                                      fieldHeight: 50,
                                      // inactiveColor: Colors.white,
                                      inactiveColor: AppColors.maincolor,
                                      selectedColor: AppColors.maincolor,
                                      activeColor: AppColors.maincolor,
                                      inactiveFillColor: Colors.white,
                                      selectedFillColor: Colors.white,
                                      fieldWidth: 40,
                                      activeFillColor: Colors.white,
                                    ),
                                    animationDuration:
                                        const Duration(milliseconds: 300),
                                    backgroundColor: Colors.white,
                                    enableActiveFill: true,

                                    // controller: textEditingController,
                                    onCompleted: (v) {
                                      print("Completed");
                                    },
                                    onChanged: (value) {
                                      print(value);
                                    },
                                    beforeTextPaste: (text) {
                                      print("Allowing to paste $text");
                                      //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                                      //but you can show anything you want here, like your pop up saying wrong paste format or etc
                                      return true;
                                    },
                                  ),
                                  heightSpace20,
                                  GestureDetector(
                                    // onTap: () => controller.LoginC(),
                                    child: Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        height: 40,
                                        width: Get.width * 0.30,
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                          color: AppColors.maincolor,
                                          borderRadius:
                                              BorderRadius.circular(5),
                                        ),
                                        child: Text(
                                          LoginItems.resetotp,
                                          style: BaseStyles.whitebold14,
                                        ),
                                      ),
                                    ),
                                  ),
                                  heightSpace50,
                                  GestureDetector(
                                    onTap: () =>
                                        Get.to(() => NewpasswordView()),
                                    // onTap: () => controller.LoginC(),
                                    child: Container(
                                      height: 50,
                                      width: Get.width,
                                      alignment: Alignment.center,
                                      margin:
                                          EdgeInsets.only(right: 10, left: 10),
                                      decoration: BoxDecoration(
                                        color: AppColors.maincolor,
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      child: Text(
                                        LoginItems.verify,
                                        style: BaseStyles.whiteBold18,
                                      ),
                                    ),
                                  ),
                                  heightSpace30,
                                  Center(
                                    child: Text(
                                      LoginItems.receive,
                                      style: BaseStyles.black14,
                                    ),
                                  ),
                                ],
                              )),
                          heightSpace30
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
