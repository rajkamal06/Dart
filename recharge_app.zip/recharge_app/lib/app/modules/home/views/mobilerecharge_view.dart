import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/constants/base_style.dart';

import '../../../../constants/app_colors.dart';
import '../../../../constants/strings.dart';
import '../../../../widgets/app_textfield.dart';
import '../../../../widgets/appbar.dart';
import '../../../../widgets/checkwithtext.dart';
import '../../../../widgets/operator.dart';
import '../controllers/mobilerecharge_controller.dart';

class MobilerechargeView extends GetView<MobilerechargeController> {
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => MobilerechargeController());
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: appbar(HomeItems.recharge_mobile, true),
          // centerTitle: false,
        ),
        body: Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: ListView(
            children: [
              heightSpace10,
              Obx(
                () => Row(
                  children: [
                    checkwithText(
                        controller: controller.selectvalue,
                        selectvalue: 1,
                        txt: 'Prepaid'),
                    widthSpace30,
                    checkwithText(
                        controller: controller.selectvalue,
                        selectvalue: 2,
                        txt: 'Postpaid'),
                  ],
                ),
              ),
              AppTextfield().textFieldwithNolable(
                width: Get.width,
                keyboardType: TextInputType.text,
                hintText: "Mobile Number",
              ),
              heightSpace10,
              AppTextfield().textFieldwithNolable(
                width: Get.width,
                keyboardType: TextInputType.text,
                hintText: "Operator",
              ),
              // heightSpace10,
              TextField(
                keyboardType: TextInputType.number,
                cursorColor: AppColors.maincolor,
                decoration: InputDecoration(
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.maincolor),
                  ),
                  border: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                  suffixIcon: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Container(
                        child: Column(
                      children: [
                        Text(
                          'Brower Plans',
                          style: BaseStyles.mainb16,
                        ),
                        Text(
                          'of all operators',
                          style: BaseStyles.grey16,
                        ),
                      ],
                    )),
                  ),
                  hintText: 'Amount',
                  hintStyle: BaseStyles.grey18,
                ),
              ),
              heightSpace20,
              Obx(
                () => Container(
                  // color: Colors.red,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      widthSpace10,
                      Checkbox(
                        visualDensity:
                            VisualDensity(horizontal: -4, vertical: -4),
                        value: controller.agree.value,
                        onChanged: (value) {
                          controller.agree.value = value ?? false;
                        },
                      ),
                      widthSpace10,
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              RechargeItems.fast,
                              overflow: TextOverflow.ellipsis,
                              style: BaseStyles.mainb16,
                            ),
                            Text(
                              RechargeItems.instantpayment,
                              overflow: TextOverflow.ellipsis,
                              style: BaseStyles.grey12,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              heightSpace30,
              Container(
                height: 50,
                width: Get.width,
                alignment: Alignment.center,
                margin: EdgeInsets.only(right: 10, left: 10),
                decoration: BoxDecoration(
                  color: AppColors.maincolor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(
                  AccountItems.proceedrecharge,
                  style: BaseStyles.whiteBold18,
                ),
              ),
              heightSpace10,
              Divider(
                color: Colors.grey,
              ),
              heightSpace30,
              Text(
                'Select an Operator',
                style: BaseStyles.blackb16,
              ),
              heightSpace10,
              Operator(txt: 'uihou', image: '', radius: 30.0),
              heightSpace10,
              Divider(
                color: Colors.grey,
              ),
              Text(
                'Home > Mobile Recharge',
                style: BaseStyles.blackb16,
              ),
              heightSpace20,
              Wrap(
                children: [
                  Text(
                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut dui et erat dapibus auctor. In hac habitasse platea dictumst. Nam maximus eget magna sit amet facilisis. ',
                    style: BaseStyles.grey14,
                  )
                ],
              )
            ],
          ),
        ));
  }
}
