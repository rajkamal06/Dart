import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../../../../constants/app_colors.dart';
import '../../../../constants/base_style.dart';
import '../../../../constants/strings.dart';
import '../controllers/bottombar_controller.dart';

class BottombarView extends GetView<BottombarController> {
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => BottombarController());
    return Obx(
      () => Scaffold(
        bottomNavigationBar: Theme(
          data: ThemeData(
            brightness: Brightness.light,
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent,
          ),
          child: BottomNavigationBar(
            unselectedItemColor: AppColors.whiteColor,
            unselectedLabelStyle: TextStyle(
                color: AppColors.whiteColor, fontWeight: FontWeight.bold),
            backgroundColor: AppColors.maincolor,
            type: BottomNavigationBarType.fixed,
            selectedItemColor: AppColors.whiteColor,
            selectedLabelStyle: BaseStyles.whitebold14,
            onTap: controller.onTabTapped,
            currentIndex: controller
                .currentIndex.value, // this will be set when a tab is tapped
            items: [
              BottomNavigationBarItem(
                label: HomeItems.home,
                icon: Image.asset(
                  ImagePath.home, height: 30,
                  color: controller.currentIndex.value == 0
                      // ignore: deprecated_member_use
                      ? AppColors.whiteColor
                      : AppColors.whiteColor,
                  // width: 20,
                  // height: 20,
                ),
              ),
              BottomNavigationBarItem(
                label: HomeItems.account,
                icon: Image.asset(
                  ImagePath.user, height: 30,
                  color: controller.currentIndex.value == 1
                      // ignore: deprecated_member_use
                      ? AppColors.whiteColor
                      : AppColors.whiteColor,
                  // width: 20,
                  // height: 20,
                ),
              ),
              BottomNavigationBarItem(
                label: HomeItems.scan,
                icon: Image.asset(
                  ImagePath.scan, height: 30,
                  color: controller.currentIndex.value == 2
                      // ignore: deprecated_member_use
                      ? AppColors.whiteColor
                      : AppColors.whiteColor,
                  // width: 20,
                  // height: 20,
                ),
              ),
              BottomNavigationBarItem(
                label: HomeItems.wallet,
                icon: Image.asset(
                  ImagePath.wallet, height: 30,
                  color: controller.currentIndex.value == 3
                      // ignore: deprecated_member_use
                      ? AppColors.whiteColor
                      : AppColors.whiteColor,
                  // width: 20,
                  // height: 20,
                ),
              ),
            ],
          ),
        ),
        body: controller.children[controller.currentIndex.value],
      ),
    );
  }
}
