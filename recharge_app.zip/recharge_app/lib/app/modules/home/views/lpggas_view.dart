import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/constants/base_style.dart';
import 'package:recharge_app/widgets/operator.dart';

import '../../../../constants/strings.dart';
import '../../../../widgets/appbar.dart';
import '../../../../widgets/checkwithtext.dart';
import '../controllers/lpggas_controller.dart';

class LpggasView extends GetView<LpggasController> {
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => LpggasController());
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: appbar(HomeItems.lpg, true),
          // centerTitle: false,
        ),
        body: Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: ListView(
            children: [
              heightSpace10,
              Container(
                child: Text(
                  'Book & Pay Instantly | Track Delivery | 2 Cr+Cylinder Delivered',
                  style: BaseStyles.black14,
                ),
              ),
              Obx(
                () => FittedBox(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      checkwithText(
                          controller: controller.selectvalue,
                          selectvalue: 1,
                          txt: 'Pay Gas Bill'),
                      widthSpace30,
                      checkwithText(
                          controller: controller.selectvalue,
                          selectvalue: 2,
                          txt: 'Book a Gas Cylinder'),
                    ],
                  ),
                ),
              ),
              heightSpace30,
              Text(
                'Select an Operator',
                style: BaseStyles.blackb16,
              ),
              heightSpace10,
              Operator(txt: 'uihou', image: '', radius: 50.0),
              heightSpace10,
            ],
          ),
        ));
  }
}
