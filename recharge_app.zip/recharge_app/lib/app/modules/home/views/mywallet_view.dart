import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/constants/app_colors.dart';
import 'package:recharge_app/constants/base_style.dart';

import '../../../../constants/strings.dart';
import '../../../../widgets/appbar.dart';

class MywalletView extends GetView {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: appbar(HomeItems.wallet, false),
          // centerTitle: false,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Available Balance  ₹ 4.00',
                  style: BaseStyles.blackbold18,
                ),
                heightSpace30,
                Text(
                  'Add Money',
                  style: BaseStyles.mainb15,
                ),
                heightSpace20,
                Container(
                  color: AppColors.maincolor.withOpacity(0.2),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
                    child: Row(
                      children: [
                        widthSpace5,
                        Icon(
                          Icons.dangerous_outlined,
                          color: AppColors.maincolor,
                        ),
                        widthSpace10,
                        Container(
                          width: Get.width * 0.70,
                          child: Text(
                            'Add Min ₹ 1000 using credit card & get 1.5X Cashback Points',
                            style: BaseStyles.black12,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                heightSpace30,
                TextField(
                  keyboardType: TextInputType.number,
                  cursorColor: AppColors.maincolor,
                  style: BaseStyles.blackbold18,
                  decoration: InputDecoration(
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: AppColors.maincolor),
                    ),
                    border: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    suffixIcon: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Container(
                          child: Text(
                        'Apply Promocode',
                        style: BaseStyles.mainb16,
                      )),
                    ),
                    hintText: '₹ Amount',
                    hintStyle: BaseStyles.blackbold18,
                  ),
                ),
                heightSpace40,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Money will be added to ',
                      style: BaseStyles.blackb14,
                    ),
                    Text(
                      'Wallet',
                      style: BaseStyles.mainb15,
                    )
                  ],
                ),
                heightSpace40,
                Container(
                  height: 50,
                  width: Get.width,
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(right: 10, left: 10),
                  decoration: BoxDecoration(
                    color: AppColors.maincolor,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Text(
                    WalletItems.proceed,
                    style: BaseStyles.whiteBold18,
                  ),
                ),
                heightSpace50,
                Text(
                  'use Your Wallet to',
                  style: BaseStyles.blackbold18,
                ),
                heightSpace40,
                Row(
                  children: [
                    Image.asset(
                      ImageWallet.money,
                      scale: 1,
                    ),
                    widthSpace10,
                    Text(
                      'Make a Payment',
                      style: BaseStyles.blackb15,
                    )
                  ],
                )
              ],
            ),
          ),
        ));
  }
}
