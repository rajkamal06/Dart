import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/app/modules/home/views/edit_profile_view.dart';
import 'package:recharge_app/constants/base_style.dart';

import '../../../../constants/app_colors.dart';
import '../../../../constants/strings.dart';
import '../../../../widgets/appbar.dart';

class AccountdetailsView extends GetView {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0.0,
          automaticallyImplyLeading: false,
          title: appbar(AccountItems.profile, true),
          // centerTitle: false,
        ),
        body: ListView(
          children: [
            Container(
              color: AppColors.maincolor,
              height: Get.height * 0.20,
              child: Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            Stack(
                              children: [
                                CircleAvatar(
                                    radius: 30,
                                    backgroundColor: AppColors.whiteColor,
                                    child: Icon(
                                      Icons.person,
                                      color: AppColors.blackColor,
                                    )),
                                Positioned(
                                  right: 0,
                                  bottom: 0,
                                  child: Icon(Icons.camera_alt),
                                )
                              ],
                            ),
                            heightSpace20,
                            GestureDetector(
                              onTap: () {
                                Get.to(() => EditProfileView());
                              },
                              child: Text(
                                'Edit Profile',
                                style: BaseStyles.whitebold14,
                              ),
                            )
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'User Name',
                              style: BaseStyles.whitebold14,
                            ),
                            heightSpace10,
                            Row(
                              children: [
                                SizedBox(
                                  width: Get.width * 0.58,
                                  child: Text(
                                    'UPI ID: 6579980765@recharge',
                                    style: BaseStyles.whitebold14,
                                  ),
                                ),
                                widthSpace10,
                                Icon(
                                  Icons.share,
                                  color: AppColors.whiteColor,
                                )
                              ],
                            )
                          ],
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
            personaldetails(
                images: ImageAccount.bank,
                textname: 'Default Bank Account ',
                textname2: 'Status Bank Of India 3200 ',
                detail: 'You will receive money in your default bank account',
                color: AppColors.greyBackground,
                defaultimage: 'assets/images/SBI.png'),
            Divider(
              color: AppColors.greyBackground,
            ),
            personaldetails(
              images: ImageAccount.cashback,
              textname: 'Cashback & Offers',
              detail: 'Stickers, Reward Points, Cashback Vouchers & Offers',
              color: AppColors.blackColor,
            ),
            Divider(
              color: AppColors.greyBackground,
            ),
            personaldetails(
              images: ImageAccount.setting,
              textname: 'Settings',
              detail: 'Payment, Security, Notifications & Reminde',
              color: AppColors.blackColor,
            ),
            Divider(
              color: AppColors.greyBackground,
            ),
            helpandlogout(image: ImageAccount.help, text: 'Help Support '),
            Divider(
              color: AppColors.greyBackground,
            ),
            helpandlogout(image: ImageAccount.logout, text: 'Logout'),
            Divider(
              color: AppColors.greyBackground,
            ),
          ],
        ));
  }

  Padding helpandlogout({required image, required text}) {
    return Padding(
      padding: const EdgeInsets.only(top: 15.0, left: 15, right: 15),
      child: Container(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(image, scale: 1, color: Colors.black),
            widthSpace20,
            Text(
              text,
              style: BaseStyles.blackb16,
            )
          ],
        ),
      ),
    );
  }

  Padding personaldetails({
    required images,
    required textname,
    textname2,
    required detail,
    color,
    defaultimage,
  }) {
    return Padding(
      padding: const EdgeInsets.only(top: 15.0, left: 15, right: 15),
      child: Container(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 15.0),
              child: Image.asset(images, scale: 1, color: color),
            ),
            widthSpace20,
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    textname,
                    style: BaseStyles.blackb16,
                  ),
                  heightSpace5,
                  Row(
                    children: [
                      defaultimage == null
                          ? Container()
                          : Image.asset(defaultimage),
                      widthSpace5,
                      textname2 == null
                          ? Container()
                          : SizedBox(
                              width: Get.width * 0.60,
                              child: Text(
                                textname2,
                                style: BaseStyles.blackb14,
                              ),
                            ),
                    ],
                  ),
                  heightSpace10,
                  Container(
                    width: Get.width * 0.70,
                    child: Text(
                      detail,
                      style: BaseStyles.greyb14,
                    ),
                  ),
                  heightSpace10,
                  // Container(
                  //   height: 2,
                  //   width: Get.width,
                  //   color: AppColors.maincolor,
                  // )
                  // Divider(
                  //   color: AppColors.maincolor,
                  //   thickness: 2,
                  // ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 30.0),
              child: Icon(
                Icons.arrow_forward_ios_sharp,
                size: 15,
              ),
            )
          ],
        ),
      ),
    );
  }
}
