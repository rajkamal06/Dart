import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/app/modules/home/views/lpggas_view.dart';
import 'package:recharge_app/app/modules/home/views/mobilerecharge_view.dart';
import 'package:recharge_app/constants/base_style.dart';
import 'package:recharge_app/widgets/drawer.dart';
import '../../../../constants/app_colors.dart';
import '../../../../constants/strings.dart';
import '../../../../widgets/custom_widgets.dart';
import '../controllers/home_controller.dart';
import 'DTHRecharge_view.dart';

class HomeView extends GetView<HomeController> {
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => HomeController());
    return Scaffold(
        appBar: CustomWidgets().gerAppBar(name: 'Home'),
        drawer: MainDrawer(),
        body: Obx(
          () => Padding(
            padding:
                EdgeInsets.only(left: 5.0, right: 5.0, bottom: 0.0, top: 5),
            child: ListView(
              children: [
                slider(),
                heightSpace20,
                fund(),
                heightSpace10,
                Text(
                  'Recharge & Bill Payments',
                  style: BaseStyles.greenb15,
                ),
                heightSpace10,
                recharegelist(),
                heightSpace10,
                balance(),
                heightSpace30,
              ],
            ),
          ),
        ));
  }

  balance() {
    return Container(
      // height: 400,
      color: AppColors.maincolor.withOpacity(0.2),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Balance     ₹0.000',
                style: BaseStyles.blackb14,
              ),
              Text(
                'Wallet History',
                style: BaseStyles.greenb12,
              ),
            ],
          ),
        ),
        Divider(
          color: AppColors.maincolor,
          thickness: 2,
        ),
        mode(
          modename: 'Online Mode >',
          text1: 'Add Balance',
          text2: 'Balance History',
          image1: ImageHome.rate,
          image2: ImageHome.report,
        ),
        Divider(
          color: AppColors.maincolor,
          thickness: 2,
        ),
        mode(
          modename: 'Manual Mode >',
          text1: 'Send Request',
          text2: 'Request History',
          image1: ImageHome.rate,
          image2: ImageHome.report,
        ),
        Divider(
          color: AppColors.maincolor,
          thickness: 2,
        ),
        heightSpace20,
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 40,
              width: Get.width * 0.40,
              alignment: Alignment.center,
              // margin: EdgeInsets.only(right: 10, left: 10),
              decoration: BoxDecoration(
                color: AppColors.whiteColor,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Text(
                HomeItems.complaints,
                style: BaseStyles.mainb15,
              ),
            ),
            Container(
              height: 40,
              width: Get.width * 0.40,
              alignment: Alignment.center,
              // margin: EdgeInsets.only(right: 10, left: 10),
              decoration: BoxDecoration(
                color: AppColors.whiteColor,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Text(
                HomeItems.commissionchart,
                style: BaseStyles.mainb15,
              ),
            ),
          ],
        ),
        heightSpace20,
        Container(
          height: 40,
          width: Get.width * 0.40,
          alignment: Alignment.center,
          // margin: EdgeInsets.only(right: 10, left: 10),
          decoration: BoxDecoration(
            color: AppColors.maincolor,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Text(
            HomeItems.commissionchart,
            style: BaseStyles.whitebold15,
          ),
        ),
        heightSpace20,
      ]),
    );
  }

  Padding mode(
      {required modename,
      required text1,
      required text2,
      required image1,
      required image2}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          SizedBox(
            width: Get.width * 0.3,
            child: Text(
              modename,
              style: BaseStyles.blackb14,
            ),
          ),
          SizedBox(
            width: Get.width * 0.3,
            child: Column(
              children: [
                Image.asset(
                  image1,
                ),
                Text(
                  text1,
                  style: BaseStyles.greenb12,
                ),
              ],
            ),
          ),
          SizedBox(
            width: Get.width * 0.3,
            child: Column(
              children: [
                Image.asset(
                  image2,
                ),
                Text(
                  text2,
                  style: BaseStyles.greenb12,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  recharegelist() {
    return GridView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            childAspectRatio: 1.1,
            crossAxisCount: 3,
            crossAxisSpacing: 0.0,
            mainAxisSpacing: 5.0),
        itemCount: controller.imagesname.length,
        itemBuilder: (BuildContext context, index) {
          return GestureDetector(
            onTap: () {
              switch (index) {
                case 0:
                  Get.to(() => MobilerechargeView());
                  // var item = Get.find<BottomBarController>();
                  // item.onTabTapped(2);

                  break;
                case 1:
                  Get.to(() => MobilerechargeView());
                  // var item = Get.find<BottomBarController>();
                  // item.onTabTapped(1);

                  break;
                case 2:
                  Get.to(() => DthrechargeView());
                  // var item = Get.find<BottomBarController>();
                  // item.onTabTapped(1);

                  break;
                case 6:
                  // Get.toNamed('/jobalert');
                  break;
                case 7:
                  Get.to(() => LpggasView());
                  // Get.toNamed('/jobalert');
                  break;
                default:
                // Get.toNamed('/homedetails');
              }
            },
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 5.0, right: 5.0, top: 10, bottom: 5),
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.whiteColor,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(0),
                      topLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                      bottomLeft: Radius.circular(0)),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      offset: const Offset(
                        2.0,
                        1.0,
                      ),
                      blurRadius: 5.0,
                      spreadRadius: 2.0,
                      color: AppColors.greyBackground.withOpacity(0.1),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      controller.imagesname[index]['images'],
                      height: 30,
                      width: 30,
                      fit: BoxFit.cover,
                    ),
                    heightSpace10,
                    Text(
                      controller.imagesname[index]['name'],
                      style: BaseStyles.blackb10,
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  fund() {
    return Container(
      height: Get.height * 0.15,
      color: AppColors.maincolor.withOpacity(0.2),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          // crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            fundtransfer(name: 'Fund Transfer', image: ImageHome.upload),
            fundtransfer(name: 'Fund Request', image: ImageHome.download),
            fundtransfer(name: 'Passbook', image: ImageHome.passbook)
          ],
        ),
      ),
    );
  }

  Container fundtransfer({required name, required image}) {
    return Container(
        child: Column(
      children: [
        Container(
          decoration: BoxDecoration(boxShadow: [
            BoxShadow(
              color: AppColors.greyBackground.withOpacity(0.2),
              blurRadius: 15.0, // soften the shadow
              spreadRadius: 3.0, //extend the shadow
              offset: Offset(
                1.0, // Move to right 10  horizontally
                3.0, // Move to bottom 10 Vertically
              ),
            )
          ]),
          child: CircleAvatar(
            radius: 30,
            backgroundColor: AppColors.whiteColor,
            child: Image.asset(
              image,
              scale: 1.2,
            ),
          ),
        ),
        heightSpace10,
        Text(
          name,
          style: BaseStyles.blackb12,
        )
      ],
    ));
  }

  slider() {
    return Stack(
      children: <Widget>[
        CarouselSlider(
          options: CarouselOptions(
              height: Get.width / 1.9,
              autoPlay: true,
              viewportFraction: 1,
              onPageChanged: (index, reason) {
                controller.sliderCurrentIndex.value = index;
              }),
          items: List.generate(1, (index) {
            return controller.slider.length != 0
                ? Container()
                : Container(
                    // color: Colors.red,
                    // padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: Image.asset(
                          ImagePath.slider,
                          fit: BoxFit.cover,
                        )),
                  );
          }),
        ),
        Positioned.fill(
          top: (Get.width / 2) - 28,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: EdgeInsets.only(right: 20),
              decoration: BoxDecoration(
                  // color: sliderContainerGrey,
                  ),
              child: SizedBox(
                height: 30,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  itemCount: 1,
                  itemBuilder: (context, index) {
                    return pointer1(index);
                  },
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  pointer1(index) {
    return Obx(
      () => Container(
        width: 8.0,
        height: 8.0,
        margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: controller.sliderCurrentIndex.value == index
              ? Color.fromRGBO(255, 255, 255, 0.9)
              : Color.fromRGBO(255, 255, 255, 0.4),
        ),
      ),
    );
  }
}
