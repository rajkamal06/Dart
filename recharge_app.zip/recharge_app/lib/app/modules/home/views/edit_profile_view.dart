import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../../../../constants/app_colors.dart';
import '../../../../constants/base_style.dart';
import '../../../../constants/strings.dart';
import '../../../../widgets/app_textfield.dart';
import '../../../../widgets/appbar.dart';
import '../../../../widgets/custom_widgets.dart';

class EditProfileView extends GetView {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0.0,
          automaticallyImplyLeading: false,
          title: appbar(AccountItems.personal, true),
          // centerTitle: false,
        ),
        // drawer: MainDrawer(),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              children: [
                GestureDetector(
                  onTap: () {
                    // Get.to(() => ImageView());
                  },
                  child: Center(
                    child: Stack(
                      alignment: Alignment.bottomRight,
                      children: [
                        CircleAvatar(
                          radius: 60,
                          backgroundColor: AppColors.whiteColor,
                          child: Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(ImageAccount.p)),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Icon(
                            Icons.flip_camera_ios_rounded,
                            color: AppColors.blackColor,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                heightSpace20,
                Container(
                  height: 40,
                  width: Get.width * 0.50,
                  decoration: BoxDecoration(
                      color: AppColors.whiteColor,
                      border: Border.all(color: Colors.transparent),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 0.2,
                          blurRadius: 5,
                          offset: Offset(0, 1), // changes position of shadow
                        ),
                      ],
                      borderRadius: BorderRadius.circular(31)),
                  child: Row(
                    children: [
                      widthSpace10,
                      Image.asset(
                        ImageAccount.check,
                        scale: 1,
                      ),
                      widthSpace10,
                      Text(
                        'KYC Verified',
                        style: BaseStyles.blackb14,
                      )
                    ],
                  ),
                ),
                heightSpace10,
                AppTextfield().textField(
                    width: Get.width,
                    keyboardType: TextInputType.text,
                    text: 'Name',
                    hintText: "Name"),
                heightSpace10,
                AppTextfield().textField(
                    width: Get.width,
                    keyboardType: TextInputType.text,
                    text: 'Email Address',
                    hintText: "Email Address",
                    suffixtxt: 'Edit'),
                heightSpace10,
                AppTextfield().textField(
                    width: Get.width,
                    keyboardType: TextInputType.text,
                    text: 'Phone No.',
                    hintText: "Phone No.",
                    suffixtxt: 'Update'),
                heightSpace30,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Wallet Status',
                      style: BaseStyles.blackb15,
                    ),
                    Text(
                      'View Benefits',
                      style: BaseStyles.mainb16,
                    ),
                  ],
                )
                // SizedBox(
                //   height: 50,
                // ),
                // CustomWidgets().roundButton(text: "Submit")
              ],
            ),
          ),
        ));
  }
}
