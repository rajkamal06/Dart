import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/constants/app_colors.dart';
import 'package:recharge_app/constants/base_style.dart';

import '../../../../constants/strings.dart';
import '../../../../widgets/appbar.dart';
import '../../../../widgets/operator.dart';

class DthrechargeView extends GetView {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: appbar(RechargeItems.dth, true),
          // centerTitle: false,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            nametitles(txt: 'RECENTS'),
            recentlist(),
            heightSpace20,
            add_new_dth(context),
            heightSpace20,
            nametitles(txt: 'PROMOS FOR YOU'),
            heightSpace10,
            feedth(),
            heightSpace20,
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Text(
                '- Terms & Conditions',
                style: BaseStyles.black16,
              ),
            )
          ],
        ));
  }

  feedth() {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'FREE DTH',
                  style: BaseStyles.blackb15,
                ),
                heightSpace10,
                Text(
                  'Every 500th Customer wins 100%cashback upto Rs 1000',
                  style: BaseStyles.black14,
                )
              ],
            ),
          ),
          Container(
            height: 40,
            width: Get.width * 0.25,
            alignment: Alignment.center,
            // margin: EdgeInsets.only(right: 10, left: 10),
            decoration: BoxDecoration(
              color: AppColors.maincolor,
              borderRadius: BorderRadius.circular(5),
            ),
            child: Text(
              RechargeItems.copy,
              style: BaseStyles.whitebold15,
            ),
          ),
        ],
      ),
    );
  }

  add_new_dth(context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Row(
        children: [
          Rounded_border(context),
          // simpleOperator(radius: 50.0, image: ImageAccount.users),
          widthSpace20,
          Container(
            child: Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'New DTH Recharge',
                    style: BaseStyles.mainb16,
                  ),
                  heightSpace5,
                  Text(
                    'Recharge for your new DTH connection ',
                    style: BaseStyles.black14,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Rounded_border(context) {
    return DottedBorder(
        dashPattern: [8, 4],
        strokeWidth: 2,
        color: AppColors.maincolor,
        strokeCap: StrokeCap.butt,
        borderType: BorderType.Circle,
        radius: Radius.circular(5),
        child: GestureDetector(
          onTap: () {
            dth_list(context);
          },
          child: CircleAvatar(
              backgroundColor: AppColors.whiteColor,
              radius: 40,
              child: Icon(
                Icons.add,
                color: AppColors.maincolor,
              )),
        ));
  }

  // dth_list(context) {
  //   return showGeneralDialog(
  //     barrierLabel: "Label",
  //     barrierDismissible: true,
  //     barrierColor: Colors.black.withOpacity(0.5),
  //     transitionDuration: Duration(milliseconds: 700),
  //     context: context,
  //     pageBuilder: (context, anim1, anim2) {
  //       return Align(
  //         alignment: Alignment.bottomCenter,
  //         child: Container(
  //           height: 300,
  //           child: SizedBox.expand(
  //               child: Padding(
  //             padding: EdgeInsets.all(15.0),
  //             child: Material(
  //               elevation: 0,
  //               color: AppColors.whiteColor,
  //               child: Column(
  //                 children: [
  //                   Row(
  //                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                     children: [
  //                       Text(
  //                         'Select an Operator',
  //                         style: BaseStyles.blackbold18,
  //                       ),
  //                       Icon(Icons.dangerous_rounded)
  //                     ],
  //                   ),
  //                   listOperator(
  //                       image: ImageAccount.users, radius: 40.0, txt: 'iouh')
  //                   // simpleOperator(image: ImageAccount.users, radius: 30.0)
  //                 ],
  //               ),
  //             ),
  //           )),
  //           margin: EdgeInsets.only(bottom: 50, left: 12, right: 12),
  //           decoration: BoxDecoration(
  //             color: Colors.white,
  //             borderRadius: BorderRadius.circular(40),
  //           ),
  //         ),
  //       );
  //     },
  //     transitionBuilder: (context, anim1, anim2, child) {
  //       return SlideTransition(
  //         position:
  //             Tween(begin: Offset(0, 1), end: Offset(0, 0)).animate(anim1),
  //         child: child,
  //       );
  //     },
  //   );
  // }
  dth_list(context) {
    return showModalBottomSheet(
        barrierColor: Colors.black.withOpacity(0.5),
        backgroundColor: AppColors.whiteColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(30),
          ),
        ),
        context: context,
        elevation: 0,
        builder: (builder) {
          return Container(
              height: 300,
              child: Padding(
                  padding: EdgeInsets.all(15.0),
                  child: Material(
                    elevation: 0,
                    color: AppColors.whiteColor,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Select an Operator',
                              style: BaseStyles.blackbold18,
                            ),
                            GestureDetector(
                                onTap: () {
                                  Get.back();
                                },
                                child: Icon(Icons.dangerous_rounded))
                          ],
                        ),
                        heightSpace10,
                        listOperator(
                            image: ImageAccount.users,
                            radius: 40.0,
                            txt: 'iouh')
                        // simpleOperator(image: ImageAccount.users, radius: 30.0)
                      ],
                    ),
                  )));
        });
  }

  recentlist() {
    return ListView.builder(
        shrinkWrap: true,
        itemCount: 1,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(15.0),
            child: Row(
              children: [
                simpleOperator(radius: 40.0, image: ImageAccount.users),
                widthSpace10,
                Container(
                  child: Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '1234567890',
                          style: BaseStyles.blackb14,
                        ),
                        heightSpace5,
                        Text(
                          'Tata Play',
                          style: BaseStyles.grey14,
                        ),
                        heightSpace5,
                        Text(
                          'Recharge of ₹199 done on 25 feb, 2022',
                          style: BaseStyles.black14,
                        ),
                      ],
                    ),
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios_sharp,
                  size: 25,
                  color: AppColors.maincolor,
                )
              ],
            ),
          );
        });
  }

  Container nametitles({required txt}) {
    return Container(
      height: 53,
      width: Get.width,
      color: AppColors.dthcolor,
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Text(
          txt,
          style: BaseStyles.blackb14,
        ),
      ),
    );
  }
}
