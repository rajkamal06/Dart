import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/app/modules/home/views/accountdetails_view.dart';
import 'package:recharge_app/constants/base_style.dart';
import 'package:recharge_app/constants/strings.dart';
import 'package:recharge_app/widgets/appbar.dart';

import '../../../../constants/app_colors.dart';

class MyaccountView extends GetView {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: appbar(HomeItems.account, false),
          // centerTitle: false,
        ),
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children: [
              GestureDetector(
                onTap: () {
                  Get.to(() => AccountdetailsView());
                },
                child: accountdetails(
                    images: ImageAccount.users,
                    textname: 'Account Details',
                    detail: 'Add or modify mobile number, Email or KYC Status',
                    color: AppColors.maincolor),
              ),
              heightSpace20,
              accountdetails(
                images: ImageAccount.upi,
                textname: 'UPI',
                detail: 'Receive & send Money directly from your bank account',
              ),
              heightSpace20,
              accountdetails(
                  images: ImageAccount.wallet,
                  textname: 'Wallet',
                  detail: 'Send Money & Pay bills instantly',
                  color: AppColors.maincolor),
            ],
          ),
        ));
  }

  Container accountdetails(
      {required images, required textname, required detail, color}) {
    return Container(
      child: Row(
        children: [
          Image.asset(images, scale: 1, color: color),
          widthSpace10,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  textname,
                  style: BaseStyles.blackb16,
                ),
                heightSpace10,
                Container(
                  width: Get.width * 0.70,
                  child: Text(
                    detail,
                    style: BaseStyles.greyb14,
                  ),
                ),
                heightSpace10,
                Container(
                  height: 2,
                  width: Get.width,
                  color: AppColors.maincolor,
                )
                // Divider(
                //   color: AppColors.maincolor,
                //   thickness: 2,
                // ),
              ],
            ),
          ),
          Icon(
            Icons.arrow_forward_ios_sharp,
            size: 15,
          )
        ],
      ),
    );
  }
}
