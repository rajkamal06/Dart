import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/constants/app_colors.dart';
import 'package:recharge_app/constants/base_style.dart';

import '../../../../constants/strings.dart';
import '../../../../widgets/appbar.dart';
import '../../../../widgets/decoration.dart';
import '../../../../widgets/operator.dart';
import '../controllers/dthpay_controller.dart';

class DthpayView extends GetView<DthpayController> {
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => DthpayController());
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: appbar(RechargeItems.dth, true),
          // centerTitle: false,
        ),
        body: Column(
          children: [
            heightSpace10,
            DTHlist(
                radius: 40.0,
                image: ImageAccount.users,
                place: null,
                txt: null),
            heightSpace40,
            Text(
              '₹856.23',
              style: BaseStyles.blackbold30,
            ),
            heightSpace40,
            Container(
              height: 45,
              decoration: BoxDecoration(
                  color: AppColors.lightgreen,
                  borderRadius: BorderRadius.circular(35)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text(
                    'Bill Date 01 Feb 22 ',
                    style: BaseStyles.black12,
                  ),
                  Text(
                    'Due Date 16 Feb 22',
                    style: BaseStyles.black12,
                  )
                ],
              ),
            ),
            heightSpace50,
            Container(
              height: 45,
              alignment: Alignment.center,
              width: Get.width * 0.90,
              decoration: BoxDecoration(
                  color: AppColors.whiteColor,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.greyBackground.withOpacity(0.2),
                      blurRadius: 15.0, // soften the shadow
                      spreadRadius: 3.0, //extend the shadow
                      offset: Offset(
                        1.0, // Move to right 10  horizontally
                        3.0, // Move to bottom 10 Vertically
                      ),
                    )
                  ],
                  borderRadius: BorderRadius.circular(35)),
              child: Text(
                'Apply Promocode',
                style: BaseStyles.mainb12,
              ),
            ),
            heightSpace30,
            Obx(
              () => Container(
                // color: Colors.red,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    widthSpace10,
                    Checkbox(
                      visualDensity:
                          VisualDensity(horizontal: -4, vertical: -4),
                      value: controller.agree.value,
                      onChanged: (value) {
                        controller.agree.value = value ?? false;
                      },
                    ),
                    widthSpace10,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Automatically Pay my bill when it is generated',
                            overflow: TextOverflow.ellipsis,
                            style: BaseStyles.black12,
                          ),
                          Text(
                            'T&C Apply',
                            overflow: TextOverflow.ellipsis,
                            style: BaseStyles.blueb12,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            heightSpace50,
            Container(
              height: 50,
              width: Get.width,
              alignment: Alignment.center,
              margin: EdgeInsets.only(right: 10, left: 10),
              decoration: BoxDecoration(
                color: AppColors.maincolor,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Text(
                'Pay ₹856.23',
                style: BaseStyles.whiteBold18,
              ),
            ),
          ],
        ));
  }
}
