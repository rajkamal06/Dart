import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:recharge_app/constants/app_colors.dart';
import 'package:recharge_app/constants/base_style.dart';

import '../../../../widgets/search.dart';
import '../controllers/scan_controller.dart';

class ScanView extends GetView<ScanController> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => ScanController());
    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        children: [
          Column(
            children: [
              SizedBox(height: Get.height * 0.68, child: _buildQrView(context)),
            ],
          ),
          Positioned(
            bottom: 240,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Obx(
                  () => GestureDetector(
                      onTap: () async {
                        controller.show.value = !controller.show.value;
                        if (controller.show.value == false) {
                          await controller.qrcontroller?.toggleFlash();
                        } else {
                          await controller.qrcontroller?.toggleFlash();
                        }
                      },
                      child: controller.show.value
                          ? Icon(
                              Icons.flash_on,
                              color: AppColors.whiteColor,
                            )
                          : Icon(
                              Icons.flash_off,
                              color: AppColors.whiteColor,
                            )),
                ),
                widthSpace30,
                Icon(
                  Icons.photo,
                  color: AppColors.whiteColor,
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 280,
            child: Container(
              height: 40,
              width: Get.width * 0.50,
              alignment: Alignment.center,
              // margin: EdgeInsets.only(right: 10, left: 10),
              decoration: BoxDecoration(
                color: AppColors.maincolor,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Text(
                'Show QR Code',
                style: BaseStyles.whitebold14,
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 230,
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(top: Radius.circular(30.0)),
                child: Container(
                  color: AppColors.whiteColor,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      heightSpace10,
                      search(),
                      heightSpace10,
                      Padding(
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Text(
                          'Recents',
                          style: BaseStyles.blackb15,
                        ),
                      ),
                      heightSpace10,
                      recentlist(),
                      heightSpace10
                    ],
                  ),
                ),
              ),
            ),
          ),

          // DraggableScrollableSheet(
          //   initialChildSize: 0.4,
          //   minChildSize: 0.4,
          //   maxChildSize: 0.4,
          //   builder: (BuildContext context, myscrollController) {
          //     return
          //   },
          // ),
        ],
      ),
    );
  }

  recentlist() {
    return Expanded(
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: 5,
          scrollDirection: Axis.horizontal,
          itemBuilder: (BuildContext context, int index) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  CircleAvatar(
                      radius: 30,
                      backgroundColor: AppColors.maincolor,
                      child: Text(
                        'M',
                        style: BaseStyles.whitebold14,
                      )),
                  heightSpace10,
                  Flexible(
                    child: Text(
                      'Phone Pe',
                      style: BaseStyles.blackb12,
                    ),
                  )
                ],
              ),
            );
          }),
    );
  }

  Widget _buildQrView(BuildContext context) {
    // For this example we check how width or tall the device is and change the scanArea and overlay accordingly.
    // var scanArea = (MediaQuery.of(context).size.width < 400 ||
    //         MediaQuery.of(context).size.height < 200)
    //     ? 200.0
    //     : 200.0;
    // To ensure the Scanner view is properly sizes after rotation
    // we need to listen for Flutter SizeChanged notification and update controller
    return QRView(
      key: qrKey,
      onQRViewCreated: controller.onQRViewCreated,
      overlay: QrScannerOverlayShape(
        borderColor: AppColors.maincolor,
        borderRadius: 10,
        borderLength: 10,
        cutOutHeight: 200,
        cutOutWidth: 250,
        borderWidth: 5,
      ),
      onPermissionSet: (ctrl, p) =>
          controller.onPermissionSet(context, ctrl, p),
    );
  }
}
