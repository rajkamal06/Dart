import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:recharge_app/app/modules/home/controllers/payment_method_controller.dart';
import 'package:recharge_app/constants/app_colors.dart';
import 'package:recharge_app/widgets/custom_widgets.dart';

class PaymentMethodView extends GetView<PaymentMethodController> {
  @override
  Widget build(BuildContext context) {
    Get.lazyPut(() => PaymentMethodController());
    return Scaffold(
        appBar: AppBar(
          title: Text('Payment Methods'),
          centerTitle: false,
          backgroundColor: AppColors.baseappColor,
        ),
        body: Obx(
          () => Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              children: [
                Row(
                  children: [
                    Radio(
                        activeColor: AppColors.baseappColor,
                        value: 1,
                        groupValue: controller.paymentMode.value,
                        onChanged: (index) {
                          controller.paymentMode.value = 1;
                        }),
                    Text('Debit Card / Credit Card / Netbanking'),
                  ],
                ),
                Row(
                  children: [
                    Radio(
                        activeColor: AppColors.baseappColor,
                        value: 2,
                        groupValue: controller.paymentMode.value,
                        onChanged: (index) {
                          controller.paymentMode.value = 2;
                        }),
                    Text('Cash'),
                  ],
                ),
                CustomWidgets().roundButton(text: 'Submit')
              ],
            ),
          ),
        ));
  }
}
