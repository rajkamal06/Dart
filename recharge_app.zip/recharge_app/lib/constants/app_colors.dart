import 'package:flutter/material.dart';

class AppColors {
  static const lightgreen = Color(0xFFDDF9F0);
  static const dthcolor = Color(0xFFECF7FC);
  static const blue = Colors.blue;
  static const baseappColor = Color(0xFFD4930E);
  static const greyBackground = Colors.grey;
  static const blackShadowColor = Color(0x40000000);
  static const lightGreenColor = Color(0xFFE9F6EF);
  static const whiteColor = Color(0xFFFFFFFF);
  static const blackColor = Colors.black;
  static const maincolor = Color(0xFF008459);
  static const lightgreenColor = Color(0xFFBFF8CB);
  static const login_otpcolor = Color(0xFFCBF1E5);
}
