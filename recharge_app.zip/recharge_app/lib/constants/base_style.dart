import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:recharge_app/constants/app_colors.dart';

SizedBox widthSpace10 = SizedBox(width: 10.0);

SizedBox heightSpace10 = SizedBox(height: 10.0);
SizedBox heightSpace5 = SizedBox(height: 5.0);
SizedBox widthSpace5 = SizedBox(width: 5.0);
SizedBox widthSpace20 = SizedBox(width: 20.0);
SizedBox widthSpace30 = SizedBox(width: 30.0);
SizedBox heightSpace20 = SizedBox(height: 20.0);
SizedBox heightSpace50 = SizedBox(height: 50.0);
SizedBox heightSpace30 = SizedBox(height: 30.0);
SizedBox heightSpace40 = SizedBox(height: 40.0);

class BaseStyles {
  static final blackbold18 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 18,
    color: AppColors.blackColor,
  );
  static final blackbold19 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 19,
    color: AppColors.blackColor,
  );
  static final blackbold30 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 30,
    color: AppColors.blackColor,
  );
  static final grey18 = GoogleFonts.koHo(
    fontSize: 18,
    color: AppColors.greyBackground,
  );
  static final blackb16 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 16,
    color: AppColors.blackColor,
  );
  static final black16 = GoogleFonts.koHo(
    // fontWeight: FontWeight.bold,
    fontSize: 16,
    color: AppColors.blackColor,
  );
  static final whitebold15 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 15,
    color: AppColors.whiteColor,
  );
  static final whitebold14 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 14,
    color: AppColors.whiteColor,
  );
  static final whiteBold18 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 18,
    color: AppColors.whiteColor,
  );

  static final main14 = GoogleFonts.koHo(
    fontSize: 14,
    color: AppColors.maincolor,
  );
  static final mainb12 = GoogleFonts.koHo(
    fontSize: 12,
    color: AppColors.maincolor,
    fontWeight: FontWeight.bold,
  );
  static final blueb12 = GoogleFonts.koHo(
    fontSize: 12,
    color: AppColors.blue,
    fontWeight: FontWeight.bold,
  );
  static final mainb15 = GoogleFonts.koHo(
    fontSize: 15,
    color: AppColors.maincolor,
    fontWeight: FontWeight.bold,
  );
  static final mainb16 = GoogleFonts.koHo(
    fontSize: 16,
    color: AppColors.maincolor,
    fontWeight: FontWeight.bold,
  );
  static final black12 = TextStyle(
    color: AppColors.blackColor,
    fontSize: 12,
    // fontWeight: FontWeight.bold,
  );
  static final greenb15 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 15,
    color: AppColors.maincolor,
  );
  static final greenb12 = GoogleFonts.koHo(
    fontWeight: FontWeight.bold,
    fontSize: 12,
    color: AppColors.maincolor,
  );
  static final blackb12 = TextStyle(
    color: AppColors.blackColor,
    fontSize: 12,
    fontWeight: FontWeight.bold,
  );
  static final blackb10 = TextStyle(
    color: AppColors.blackColor,
    fontSize: 10,
    fontWeight: FontWeight.bold,
  );
  static final blackb14 = TextStyle(
    color: AppColors.blackColor,
    fontSize: 14,
    fontWeight: FontWeight.bold,
  );
  static final black14 = TextStyle(
    color: AppColors.blackColor,
    fontSize: 14,
    // fontWeight: FontWeight.bold,
  );
  static final blackb15 = TextStyle(
    color: AppColors.blackColor,
    fontSize: 15,
    fontWeight: FontWeight.bold,
  );
  static final grey12 = TextStyle(
    color: AppColors.greyBackground.withOpacity(0.7),
    fontSize: 12,
    // fontWeight: FontWeight.bold,
  );
  static final greyb14 = TextStyle(
    color: AppColors.greyBackground.withOpacity(0.7),
    fontSize: 14,
    fontWeight: FontWeight.bold,
  );
  static final grey14 = TextStyle(
    color: AppColors.greyBackground.withOpacity(0.7),
    fontSize: 14,
    // fontWeight: FontWeight.bold,
  );
  static final grey16 =
      TextStyle(color: AppColors.greyBackground.withOpacity(0.7), fontSize: 16
          // fontWeight: FontWeight.bold,
          );
}
