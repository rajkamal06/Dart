class ImagePath {
  static const String logimages = 'assets/images/login.png';
  static const String bleft = 'assets/images/bleft.png';
  static const String tright = 'assets/images/tright.png';
  static const String home = 'assets/images/home.png';
  static const String scan = 'assets/images/scan.png';
  static const String wallet = 'assets/images/wallet.png';
  static const String user = 'assets/images/user.png';
  static const String s = 'assets/images/lab.png';
  static const String slider = 'assets/images/ss.jpeg';
}

class ImageHome {
  static const String download = 'assets/homeimages/download.png';
  static const String passbook = 'assets/homeimages/passbook.png';
  static const String upload = 'assets/homeimages/upload.png';
  static const String rate = 'assets/homeimages/rate.png';
  static const String report = 'assets/homeimages/bal.png';
}

class LogoPath {
  static const String logo = 'assets/logo/logo.png';
}

class HomeItems {
  static const String home = 'Home';
  static const String recharge_mobile = 'Recharge or Pay Mobile Bill';
  static const String account = 'My Account';
  static const String lpg = 'LPG Gas Cylinder';
  static const String scan = 'Scan QR';
  static const String wallet = 'My Wallet';
  static const String complaints = 'Complaints';
  static const String commissionchart = 'Commission Chart';
}

class WalletItems {
  static const String proceed = 'Proceed';
}

class ImageWallet {
  static const String money = 'assets/images/money.png';
}

class AccountItems {
  static const String proceed = 'Proceed';
  static const String personal = 'Personal';
  static const String profile = 'Profile';
  static const String proceedrecharge = 'Proceed to Recharge';
}

class RechargeItems {
  static const String fast = '>> Fast Forward';
  static const String instantpayment =
      'Instant payment from your recharge balance';
  static const String personal = 'Personal';
  static const String profile = 'Profile';
  static const String dth = 'Recharge DTH or TV';
  static const String copy = 'Copy';
}

class ImageAccount {
  static const String upi = 'assets/images/upi.png';
  static const String users = 'assets/images/users.png';
  static const String p = 'assets/images/p.png';
  static const String wallet = 'assets/images/walletaccount.png';
  static const String bank = 'assets/images/bank.png';

  static const String check = 'assets/images/check.png';

  static const String cashback = 'assets/images/cashback.png';

  static const String setting = 'assets/images/setting.png';
  static const String help = 'assets/images/help.png';

  static const String logout = 'assets/images/logout.png';
}

class LoginItems {
  static const String login = '  Login';
  static const String forget1 = '  Forget';
  static const String submit = '  Submit';
  static const String save = '  Save';
  static const String newpassword = '  New Password';

  static const String confirmpassword = 'Confirm Password';
  static const String otp = '  OTP';
  static const String resetotp = 'Reset OTP';
  static const String verify = 'Verify';
  static const String receive = 'Didn\'t receive the code?';
  static const String forget = 'Forget Password';
  static const String password = 'Password';
  static const String email = 'Eamil Address';
  static const String signup = '  Sign Up';
  static const String verificationcode =
      'Please enter the 6-digit verification code we sent via SMS :';
  static const String mobile = 'Mobile Number';
  static const String name = 'Name';
  static const String have_account = 'Don’t have an account ?';
}

class DrawerItems {
  static const String home = 'Home';
  static const String myRide = 'My Rides';
  static const String cancelRide = 'Cancelled Rides';
  static const String offer = 'Offers';
  static const String aboutUs = 'About Us';
  static const String support = 'Support';
  static const String notification = 'Notification';
  static const String legal = 'Legal';
  static const String terms = 'Term & Condition';
  static const String refund = 'Refund & Cancellation';
  static const String privacy = 'Privacy Policy';
  static const String cookiePolicy = 'Cookie Policy';
  static const String offerTerms = 'Offer Terms';
  static const String phishingFraud = 'Phishing & Fraud';
  static const String logout = 'Logout';
}
