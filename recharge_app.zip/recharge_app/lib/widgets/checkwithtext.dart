import 'package:flutter/material.dart';
import 'package:recharge_app/constants/app_colors.dart';

import '../constants/base_style.dart';

Row checkwithText(
    {required txt, required controller, required int selectvalue}) {
  return Row(
    children: [
      Radio(
          activeColor: AppColors.maincolor,
          value: selectvalue,
          groupValue: controller.value,
          onChanged: (index) {
            controller.value = selectvalue;
          }),
      Text(
        txt,
        style: BaseStyles.blackb15,
      ),
    ],
  );
}
