import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:recharge_app/constants/base_style.dart';
import 'package:recharge_app/constants/strings.dart';

import '../app/modules/home/views/dthpay_view.dart';
import '../constants/app_colors.dart';

Operator({required radius, required txt, required image}) {
  return SizedBox(
      height: 150,
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: 5,
          scrollDirection: Axis.horizontal,
          itemBuilder: (BuildContext context, int index) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 0.2,
                          blurRadius: 5,
                          offset: Offset(0, 1), // changes position of shadow
                        ),
                      ],
                    ),
                    child: CircleAvatar(
                      radius: radius,
                      backgroundColor: AppColors.whiteColor,
                      backgroundImage: AssetImage(
                        ImageAccount.users,
                      ),
                    ),
                  ),

                  // Container(
                  //     height: 100,
                  //     decoration: BoxDecoration(
                  //       shape: BoxShape.circle,
                  //       color: Colors.white,
                  //       boxShadow: [
                  //         BoxShadow(
                  //           color: Colors.grey.withOpacity(0.5),
                  //           spreadRadius: 0.2,
                  //           blurRadius: 5,
                  //           offset: Offset(0, 1), // changes position of shadow
                  //         ),
                  //       ],
                  //     ),
                  //     child: Image.asset(
                  //       ImageAccount.users,
                  //     )),
                  heightSpace10,
                  Text(
                    txt,
                    style: BaseStyles.blackb14,
                  )
                ],
              ),
            );
          }));
}

simpleOperator({required radius, required image}) {
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 0.2,
                blurRadius: 5,
                offset: Offset(0, 1), // changes position of shadow
              ),
            ],
          ),
          child: CircleAvatar(
            radius: radius,
            backgroundColor: AppColors.whiteColor,
            backgroundImage: AssetImage(
              ImageAccount.users,
            ),
          ),
        ),
      ],
    ),
  );
}

listOperator({required radius, required image, required txt}) {
  return SizedBox(
    height: 225,
    child: GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            childAspectRatio: .8,
            crossAxisCount: 3,
            crossAxisSpacing: 10.0,
            mainAxisSpacing: 5.0),
        itemCount: 9,
        itemBuilder: (BuildContext ctx, index) {
          return GestureDetector(
            onTap: () {
              Get.back();
              Get.to(() => DthpayView());
            },
            child: Column(
              children: [
                // heightSpace10,
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 0.2,
                        blurRadius: 5,
                        offset: Offset(0, 1), // changes position of shadow
                      ),
                    ],
                  ),
                  child: CircleAvatar(
                    radius: radius,
                    backgroundColor: AppColors.whiteColor,
                    backgroundImage: AssetImage(
                      ImageAccount.users,
                    ),
                  ),
                ),
                heightSpace5,
                Text(
                  txt,
                  style: BaseStyles.blackb14,
                )
              ],
            ),
          );
        }),
  );
}

DTHlist({required radius, required image, required txt, required place}) {
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Container(
      padding: EdgeInsets.only(bottom: 20, top: 10, left: 10),
      color: AppColors.dthcolor,
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 0.2,
                  blurRadius: 5,
                  offset: Offset(0, 1), // changes position of shadow
                ),
              ],
            ),
            child: CircleAvatar(
              radius: radius,
              backgroundColor: AppColors.whiteColor,
              backgroundImage: AssetImage(
                ImageAccount.users,
              ),
            ),
          ),
          widthSpace20,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '8234567890',
                style: BaseStyles.blackb12,
              ),
              heightSpace10,
              Text('Postpaid Rajasthan', style: BaseStyles.main14)
            ],
          )
        ],
      ),
    ),
  );
}
