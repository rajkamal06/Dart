import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../app/modules/home/views/edit_profile_view.dart';
import '../constants/app_colors.dart';
import '../constants/base_style.dart';
import '../constants/strings.dart';

class MainDrawer extends StatefulWidget {
  const MainDrawer({Key? key}) : super(key: key);

  @override
  _MainDrawerState createState() => _MainDrawerState();
}

class _MainDrawerState extends State<MainDrawer> {
  var legal = false;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 250,
      child: Drawer(
        backgroundColor: AppColors.maincolor,
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: SafeArea(
            child: ListView(
              children: [
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Get.back();
                        Get.to(() => EditProfileView());
                      },
                      child: CircleAvatar(
                        radius: 35,
                        backgroundColor: Colors.white,
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(LogoPath.logo)),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    SizedBox(
                      width: 140,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Manoj',
                            style: BaseStyles.whiteBold18,
                          ),
                          Text(
                            'Manoj@gmail.com',
                            style: BaseStyles.whitebold15,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 30,
                ),
                title(
                    icon: Icons.home,
                    title: DrawerItems.home,
                    ontap: () {
                      Get.back();
                    }),
                titlewithimage(
                    path: ImageAccount.users,
                    title: DrawerItems.myRide,
                    ontap: () {
                      Get.back();
                    }),
                title(
                    icon: Icons.cancel_outlined,
                    title: DrawerItems.cancelRide,
                    ontap: () {
                      Get.back();
                    }),
                titlewithimage(
                    path: ImageAccount.users,
                    title: DrawerItems.offer,
                    ontap: () {
                      Get.back();
                    }),
                title(
                    icon: Icons.info_outline,
                    title: DrawerItems.aboutUs,
                    ontap: () {
                      Get.back();
                    }),
                title(
                    icon: Icons.contact_support_outlined,
                    title: DrawerItems.support),
                title(
                    icon: Icons.notifications_active_outlined,
                    title: DrawerItems.notification),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      legal = !legal;
                    });
                  },
                  child: Container(
                    color: Colors.transparent,
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Image.asset(
                              ImageAccount.users,
                              width: 20,
                              color: Colors.white,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              DrawerItems.legal,
                              style: BaseStyles.whitebold15,
                            ),
                          ],
                        ),
                        Icon(
                            legal == true
                                ? Icons.arrow_drop_down_outlined
                                : Icons.arrow_drop_up_outlined,
                            color: Colors.white),
                      ],
                    ),
                  ),
                ),
                legal == true
                    ? Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            legalItems(
                                items: DrawerItems.terms,
                                ontap: () {
                                  Get.back();
                                }),
                            legalItems(items: DrawerItems.refund),
                            legalItems(items: DrawerItems.privacy),
                            legalItems(items: DrawerItems.cookiePolicy),
                            legalItems(items: DrawerItems.offerTerms),
                            legalItems(items: DrawerItems.phishingFraud),
                          ],
                        ),
                      )
                    : Container(),
                title(icon: Icons.exit_to_app, title: DrawerItems.logout),
              ],
            ),
          ),
        ),
      ),
    );
  }

  GestureDetector legalItems({Function()? ontap, items}) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        padding: const EdgeInsets.all(8.0),
        color: Colors.transparent,
        child: Text(
          items,
          style: BaseStyles.whitebold14,
        ),
      ),
    );
  }

  title({required title, required icon, Function()? ontap}) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        padding: const EdgeInsets.all(8.0),
        color: Colors.transparent,
        child: Row(
          children: [
            Icon(
              icon,
              color: Colors.white,
            ),
            SizedBox(
              width: 10,
            ),
            Text(
              title,
              style: BaseStyles.whitebold15,
            ),
          ],
        ),
      ),
    );
  }

  titlewithimage({required title, required path, Function()? ontap}) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        color: Colors.transparent,
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Image.asset(
              path,
              width: 20,
              color: Colors.white,
            ),
            SizedBox(
              width: 10,
            ),
            Text(
              title,
              style: BaseStyles.whitebold15,
            ),
          ],
        ),
      ),
    );
  }
}
