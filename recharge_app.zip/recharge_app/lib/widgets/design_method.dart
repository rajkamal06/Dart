import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants/app_colors.dart';
import '../constants/base_style.dart';
import '../constants/strings.dart';

Container designfunction({required name}) {
  return Container(
    height: Get.height * 0.25,
    decoration: BoxDecoration(
      color: AppColors.login_otpcolor,
      borderRadius: BorderRadius.only(
        bottomRight: Radius.circular(50),
        bottomLeft: Radius.circular(50),
      ),
      boxShadow: [
        BoxShadow(
          color: AppColors.greyBackground.withOpacity(0.2),
          blurRadius: 3.0, // soften the shadow
          spreadRadius: 2.0, //extend the shadow
          offset: Offset(
            0.0, // Move to right 10  horizontally
            3.0, // Move to bottom 10 Vertically
          ),
        )
      ],
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Text(name, style: BaseStyles.blackbold18),
        ),
        Image.asset(
          ImagePath.logimages,
          height: 150,
          fit: BoxFit.cover,
        ),
      ],
    ),
  );
}
