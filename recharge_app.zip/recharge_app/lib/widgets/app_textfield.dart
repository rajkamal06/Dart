import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../constants/base_style.dart';

class AppTextfield {
  textFieldContainer(
      {required width,
      @required keyboardType,
      controller,
      maxLines,
      read,
      String? Function(String?)? validator,
      @required text,
      @required hintText,
      double? height}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          text,
          // style
          //  .blacknormal12,
        ),
        const SizedBox(
          height: 5,
        ),
        Container(
          alignment: Alignment.center,
          height: height ?? 45,
          width: width,
          decoration: BoxDecoration(
              border: Border.all(color: Colors.transparent),
              color: Colors.white,
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 10)
              ],
              borderRadius: BorderRadius.circular(5)),
          child: TextFormField(
            keyboardType: keyboardType,
            controller: controller,
            validator: validator,
            readOnly: read ?? false,
            autofocus: false,
            maxLines: maxLines ?? 1,
            decoration: InputDecoration(
              hintText: hintText,
              isDense: true,
              prefixText: '+91',
              prefixStyle: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.fromLTRB(10, 10, 0, 0),
              hintStyle: const TextStyle(
                color: Colors.black,
                fontSize: 12,
              ),
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.transparent,
                ),
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  textField(
      {required width,
      @required keyboardType,
      controller,
      suffixtxt,
      maxLines,
      read,
      String? Function(String?)? validator,
      @required text,
      @required hintText,
      double? height}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          text,
          // style
          //  .blacknormal12,
        ),
        const SizedBox(
          height: 5,
        ),
        Container(
          alignment: Alignment.center,
          height: height ?? 55,
          width: width,
          decoration: BoxDecoration(
              border: Border.all(color: Colors.transparent),
              color: Colors.white,
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 10)
              ],
              borderRadius: BorderRadius.circular(5)),
          child: TextFormField(
            keyboardType: keyboardType,
            controller: controller,
            validator: validator,
            readOnly: read ?? false,
            autofocus: false,
            maxLines: maxLines ?? 1,
            decoration: InputDecoration(
              hintText: hintText,
              isDense: true,
              border: InputBorder.none,
              suffixIcon: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                    child: Text(
                  suffixtxt ?? '',
                  style: BaseStyles.mainb16,
                )),
              ),
              contentPadding: const EdgeInsets.fromLTRB(10, 10, 0, 0),
              hintStyle: const TextStyle(
                color: Colors.black,
                fontSize: 12,
              ),
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.transparent,
                ),
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  textFieldwithNolable(
      {required width,
      @required keyboardType,
      controller,
      maxLines,
      read,
      String? Function(String?)? validator,
      @required hintText,
      double? height}) {
    return Container(
      alignment: Alignment.center,
      height: height ?? 45,
      width: width,
      child: TextFormField(
        keyboardType: keyboardType,
        controller: controller,
        validator: validator,
        readOnly: read ?? false,
        autofocus: false,
        maxLines: maxLines ?? 1,
        decoration: InputDecoration(
          hintText: hintText,
          isDense: true,
          contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          hintStyle: BaseStyles.grey18,
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.grey),
          ),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: AppColors.maincolor),
          ),
          border: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.grey),
          ),
        ),
      ),
    );
  }
}
