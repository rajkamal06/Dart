import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../constants/app_colors.dart';
import '../constants/base_style.dart';
import 'decoration.dart';

Widget search() {
  return Align(
    alignment: Alignment.topCenter,
    child: Container(
      height: 46,
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
      width: Get.width * 0.90,
      decoration: decoration(),
      child: TextField(
        // onTap: () => Get.to(() => SearchView()),
        keyboardType: TextInputType.text,
        cursorColor: AppColors.maincolor,
        style: BaseStyles.main14,
        readOnly: true,
        textCapitalization: TextCapitalization.words,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          suffixIcon: Padding(
            padding: const EdgeInsets.only(left: 5),
            child: Container(
              decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(color: AppColors.whiteColor),
                ),
              ),
              child: Icon(
                Icons.search,
                color: AppColors.greyBackground,
              ),
            ),
          ),
          hintText: 'Enter Mobile number or name',
          hintStyle: BaseStyles.grey12,
          border: InputBorder.none,
        ),
      ),
    ),
  );
}
