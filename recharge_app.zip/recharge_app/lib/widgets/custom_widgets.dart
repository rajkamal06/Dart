import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:recharge_app/constants/base_style.dart';

import '../constants/app_colors.dart';

class CustomWidgets {
  AppBar gerAppBar({name}) {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      toolbarHeight: 70,
      title: Text(name, style: BaseStyles.whiteBold18),
      leading: Builder(
        builder: (context) => Padding(
          padding: const EdgeInsets.all(5.0),
          child: CircleAvatar(
            radius: 15,
            backgroundColor: AppColors.whiteColor,
            child: IconButton(
              icon:
                  Icon(Icons.menu_sharp, color: AppColors.maincolor, size: 30),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        ),
      ),
      actions: [
        Icon(Icons.person_add_alt_1_outlined,
            color: AppColors.whiteColor, size: 30),
        widthSpace20,
        Icon(Icons.notifications_none_outlined,
            color: AppColors.whiteColor, size: 30),
        widthSpace20
      ],
      flexibleSpace: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30)),
            gradient: LinearGradient(
                colors: [AppColors.maincolor, AppColors.maincolor],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter)),
      ),
    );
  }

  BoxDecoration boxDecoration({required double radius, backgroundColor}) {
    return BoxDecoration(
        color: backgroundColor ?? Colors.white,
        boxShadow: [BoxShadow(color: Colors.grey.shade300, blurRadius: 3)],
        borderRadius: BorderRadius.circular(radius));
  }

  GestureDetector roundButton(
      {required text, Function()? ontap, double? width}) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 20),
        alignment: Alignment.center,
        width: width ?? Get.width,
        margin: EdgeInsets.all(30),
        decoration: CustomWidgets()
            .boxDecoration(radius: 10, backgroundColor: AppColors.baseappColor),
        // child: Text(text, style: BaseStyles.whitebold18),
      ),
    );
  }

  GestureDetector customroundButtonWithIcon(
      {required text,
      Function()? ontap,
      double? width,
      required icon,
      iconColor,
      backgroundColor,
      textStyle}) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10),
        alignment: Alignment.center,
        width: width ?? Get.width,
        decoration: CustomWidgets().boxDecoration(
            radius: 10,
            backgroundColor: backgroundColor ?? AppColors.baseappColor),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: iconColor),
            SizedBox(
              width: 5,
            ),
            // Text(text, style: textStyle ?? BaseStyles.whitebold18),
          ],
        ),
      ),
    );
  }
}
