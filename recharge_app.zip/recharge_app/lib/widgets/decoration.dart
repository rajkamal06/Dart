import 'package:flutter/material.dart';

import '../constants/app_colors.dart';

BoxDecoration decoration() {
  return BoxDecoration(
      borderRadius: BorderRadius.circular(5),
      color: AppColors.whiteColor,
      boxShadow: [
        BoxShadow(
          color: AppColors.greyBackground.withOpacity(0.2),
          blurRadius: 15.0, // soften the shadow
          spreadRadius: 3.0, //extend the shadow
          offset: Offset(
            1.0, // Move to right 10  horizontally
            3.0, // Move to bottom 10 Vertically
          ),
        )
      ]);
}
